# Digital_Filters
Comparison of several digital filters
1. Moving Average
2. Exponential filter
3. Kalman filter
